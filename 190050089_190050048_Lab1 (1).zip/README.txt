README

There are eight VHDL files: 4 defining gates and components and 4 testbenches for each of the entities. The 4 testbenches allows us to test the output of each of the component separately and hence ensure the correctness of the cicuit. 
Make a new project with the name lab1 in Quartus and add the VHDL files to it.

Description of VHDL files:
The gates are defined as separate entity in their respective VHDL files: AndGate.vhd, OrGate.vhd, NotGate.vhd. The input for AndGate and OrGate is A,B (two bits) while for NotGate is A(single bit). They perform the respective operations and return the result as output(single bit).	
Lab1.vhd is the main project file which contains a parallel implementation of all the gates. It takes 2 inputs, A and B, and outputs 3 bits: AND_OUT = A AND B, OR_OUT = A OR B, NOT_OUT = NOT A. It uses the AndGate, OrGate and NotGate entities as components to achieve this.

There are 4 TestBench files: 3 for each of the gates(named TestBench###.vhd where ### is the name of corresponding gate) and one for the Lab1 entity(named TestBench.vhd) which runs all the gates parallely.
Each of the testbench files contain one instance for the corresponding component to be tested. Futher signals are added to give the inputs and get the outputs from the components. 
In all the testbenches, the input signals(a and b in TestBenchAnd, TestBenchOr, TestBench and a in TestBenchNot) is varied over all the possible inputs with a wait of 5 nanoseconds.

Output:
The screenshot of the outputs in ModelSim are given in the Screenshots folder. The same can be regenrated by adding the testbench in the settings(The testbenches will have to be run one after the other as the software does not allow to run multiple testbenches together) and running the RTL simulation tool.

Submitted by: Pradipta Parag Bora(190050089) and Harshit Gupta(190050048)